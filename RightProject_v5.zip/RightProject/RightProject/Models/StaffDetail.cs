﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace RightProject.Models
{
	public class StaffDetail
	{
		
		public string Name { get; set; }

			//public int age { get; set; }

		public string Department { get; set; }   

		public string Ability { get; set; } 



	}
}

