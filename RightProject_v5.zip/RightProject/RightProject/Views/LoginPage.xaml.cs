﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace RightProject
{
	public partial class LoginPage : ContentPage
	{
		public LoginPage ()
		{
			InitializeComponent ();
		}
		/*
		private void SayHelloButton_OnClicked(object sender, EventArgs e)

		{
			

			var name = NameEntry.Text;
			var greeting = "Hello " + name;
			GreetingLabel.Text = greeting;
		}*/
	}
}

