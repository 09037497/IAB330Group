﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using RightProject.Models;
//using RightProject.ViewModel;
using System.ComponentModel;

namespace RightProject
{
	public class BetterStaffList : INotifyPropertyChanged

	{	
		private string _greeting;

		public string Greeting 
		{
			get{ return _greeting;} 

			set{ _greeting = value;
				OnPropertyChanged ("Greeting");

			} 
		}

		public string Name { get; set;}

		public ICommand SayHelloCommand { get; set;}

		public ObservableCollection<StaffDetail> StaffDetails { get; set; }


		public BetterStaffList ()
		{
			Greeting = "Staff List here";
			Name = "enter name";

			StaffDetails = new ObservableCollection<StaffDetail> 
			{
				new StaffDetail{Name = "May", Department = "Programmer", Ability = "C#"},
				new StaffDetail{Name = "Sam", Department = "Senior Programmer", Ability = "C++"},
				new StaffDetail{Name = "Eva", Department = "Programmer", Ability = "Java"}			

			};

			SayHelloCommand = new Command (SayHello);
		}

		public void SayHello()
		{
			Greeting = "Hello" + Name;
		}

		#region INPC
		public void OnPropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
				PropertyChanged (this, new PropertyChangedEventArgs (propertyName));
		}

		public event PropertyChangedEventHandler PropertyChanged;
		#endregion
	}
}

