﻿
using System;
using System.Collections.Generic;

using Xamarin.Forms; 

namespace RightProject
{
	public partial class MainView 
	{
		public MainView ()
		{
			InitializeComponent ();
		}
	}
}

