﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace RightProject
{
	public partial class StaffList 
	{
		public StaffList ()
		{
			InitializeComponent ();
			this.BindingContext = new BetterStaffList ();// connect to BetterStaffList
		}
	}
}

